Installation:

`pip install -r requirements.txt`


Thats it!

`scrapy crawl miamidade`